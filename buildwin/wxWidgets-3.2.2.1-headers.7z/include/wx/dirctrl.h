/////////////////////////////////////////////////////////////////////////////
// Name:        wx/dirctrl.h
// Purpose:     Directory control base header
// Author:      Julian Smart
// Modified by:
// Created:
// Copyright:   (c) Julian Smart
// Licence:     wxWindows Licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_DIRCTRL_H_BASE_
#define _WX_DIRCTRL_H_BASE_

#include "wx/generic/dirctrlg.h"

#endif
    // _WX_DIRCTRL_H_BASE_
